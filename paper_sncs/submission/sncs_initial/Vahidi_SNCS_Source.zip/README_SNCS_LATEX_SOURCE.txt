SN Computer Science LaTeX source package.
This package contains exactly one .tex file:
Vahidi_SNCS_Main.tex
All source-package files are intentionally placed at the same folder level for Editorial Manager upload. There are no subfolders.
Build command:
latexmk -pdf Vahidi_SNCS_Main.tex
Recommended initial upload remains the PDF manuscript unless Editorial Manager requests LaTeX source files.
