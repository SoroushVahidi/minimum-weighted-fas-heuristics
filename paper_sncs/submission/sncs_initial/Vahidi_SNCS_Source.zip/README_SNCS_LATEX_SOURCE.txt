SN Computer Science LaTeX source package.
This package contains exactly one .tex file:
Vahidi_SNCS_Main.tex
Build command:
latexmk -pdf Vahidi_SNCS_Main.tex
The package includes only support files needed to compile the manuscript.
