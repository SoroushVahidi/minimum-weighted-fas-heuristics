SN Computer Science LaTeX source package for:
An Incumbent-Protected Component-Local Heuristic for Minimum Weighted Feedback Arc Set on Sparse Digraphs
This source package is intended for journal upload only if LaTeX source files are requested. It contains exactly one .tex file:
Vahidi_SNCS_Main.tex
Build command:
latexmk -pdf Vahidi_SNCS_Main.tex
The recommended initial Editorial Manager upload remains the PDF manuscript unless the portal requests source files.
