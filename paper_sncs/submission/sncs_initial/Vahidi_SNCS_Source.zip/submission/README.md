# Submission Materials (SN Computer Science)

**Status:** first SNCS retargeting pass (see `docs/sncs_preparation_202606/`). Not yet finalized for portal upload.

This directory holds the SNCS build helper (`README_BUILD.txt`) and, once prepared, the clean upload bundle under `sncs_initial/`.

Not yet created in this pass (deferred to a later pass, see `docs/sncs_preparation_202606/SUBMISSION_PACKAGE_STATUS.md`):

- SNCS-specific cover letter (the COAP cover letter in `paper_coap/submission/cover_letter.tex` is COAP-specific and must not be reused verbatim)
- SNCS-specific related-manuscripts statement (the COAP version in `paper_coap/submission/related_manuscripts_statement.tex` is COAP-specific; see `docs/sncs_preparation_202606/OVERLAP_AND_DISCLOSURE_AUDIT.md` for the disclosure analysis that must inform the SNCS version)

The COAP submission package under `paper_coap/submission/final_upload/` is the historical, unmodified COAP snapshot and is not affected by this directory.
