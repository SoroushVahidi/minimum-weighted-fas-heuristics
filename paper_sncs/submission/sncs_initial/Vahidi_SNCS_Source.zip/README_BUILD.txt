Build note for SNCS backup source package

This package has been flattened for submission backup use.
It contains exactly one TeX file: Vahidi_SNCS_Main.tex.
Bibliography, class/style, and figure support files are included separately.
Build with: latexmk -pdf Vahidi_SNCS_Main.tex
Recommended initial upload remains the PDF manuscript only.
Upload this ZIP only if Editorial Manager requires LaTeX source files.
