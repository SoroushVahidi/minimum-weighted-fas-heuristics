# Reproduce

## Quick checks

```bash
python -m compileall src/mwfas scripts
python experiments/combined/build_manuscript_results_digest.py
python paper/scripts/build_paper_results_assets.py
```

## Inspect the committed summary tables

- `experiments/combined/tables/`
- `experiments/exp2_ablation/summary/`
- `experiments/exp3_exact_small/summary/`
- `experiments/exp4_external_baselines/summary/`
- `experiments/exp5_lolib_dense/summary/`

## Optional reruns

The following commands are time-consuming and may require datasets or external tools that are not bundled in this artifact:

```bash
python scripts/run_lrta.py --help
python scripts/run_wmsf.py --help
python scripts/run_ipsns.py --help
python scripts/run_exact.py --help
python scripts/run_drmaciver_fas.py --help
```

Exact reproduction of runtimes or external-baseline behavior may vary by machine,
dependency versions, and availability of third-party tools.
