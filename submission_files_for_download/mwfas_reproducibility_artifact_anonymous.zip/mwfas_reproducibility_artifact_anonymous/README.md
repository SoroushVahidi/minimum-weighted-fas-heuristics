# Anonymous Reproducibility Artifact

This package is an anonymous reproducibility artifact prepared for double-anonymized review.
It contains the implementation, experiment support scripts, selected committed summaries,
paper-asset builders, and documentation needed to inspect and reproduce the manuscript-facing
tables and figures without exposing author identity.

## Included

- `src/mwfas/` core implementation modules
- `scripts/` command-line wrappers for the reported methods
- selected experiment configs, postprocessors, committed summaries, and paper tables
- manuscript asset builders and provenance notes
- dataset and baseline reference notes

## Excluded

- Git history and repository metadata
- raw experiment outputs, logs, downloads, and external cloned tools
- manuscript PDFs and TeX build artifacts
- private paths, personal identifiers, and non-anonymized submission files

## Dependency setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Inspect committed summaries

- `experiments/combined/summary/` contains the manuscript results digest.
- `experiments/combined/tables/` contains the paper-facing CSV tables.
- experiment-specific `summary/` and `tables/` directories contain the committed supporting files.

## Regenerate manuscript result tables and figures from committed summaries

```bash
python paper/scripts/build_paper_results_assets.py
```

This command rebuilds the manuscript-facing tables and vector figures from the committed
summary files without rerunning the reported experiments.

## Optional reruns

Time-consuming reruns are documented in `REPRODUCE.md`. Full reruns are optional and may
depend on external tools, dataset access, and the local software environment.

## Public dataset and tool sources

- graph-benchmarks: https://github.com/alidasdan/graph-benchmarks
- LOLIB: https://grafo.etsii.urjc.es/optsicom/lolib.html
- python-igraph: https://python.igraph.org/
- DRMacIver/FAS: https://github.com/DRMaciver/Feedback-Arc-Set

No author-identifying information is intentionally included in this artifact.
A public repository and archival release will be provided after acceptance.
